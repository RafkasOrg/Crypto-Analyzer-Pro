// auth.js final
const login = () => { ... }