// whaleTracker.js final
function trackWhales() { ... }