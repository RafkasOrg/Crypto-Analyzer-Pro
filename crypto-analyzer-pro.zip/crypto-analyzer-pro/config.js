// config.js
const API_KEY = 'your-api-key';