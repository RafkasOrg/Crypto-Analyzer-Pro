// dashboard.js final
const loadDashboard = () => { ... }