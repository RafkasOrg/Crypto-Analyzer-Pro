// Dummy Config
const config = {};